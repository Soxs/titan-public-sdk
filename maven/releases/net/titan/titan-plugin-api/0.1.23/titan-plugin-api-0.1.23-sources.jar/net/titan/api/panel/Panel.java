package net.titan.api.panel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/// Fluent builder for plugin side panels. A plugin's
/// {@code buildPanel(panelId, Panel)} method receives a {@code Panel} and
/// appends commands (text, buttons, checkboxes, sliders, tables, ...). The
/// runtime serializes the resulting command list into the shared panel wire
/// format and the controller replays the commands with ImGui.
///
/// This mirrors the native {@code titan::Panel} and the TypeScript panel
/// builder so all three plugin surfaces have identical capabilities.
public final class Panel {
    private final List<PanelElement> elements = new ArrayList<>();

    // --- Text ---
    public Panel text(String s) { push(PanelElementType.TEXT, s); return this; }
    public Panel wrapped(String s) { push(PanelElementType.TEXT_WRAPPED, s); return this; }
    public Panel disabled(String s) { push(PanelElementType.TEXT_DISABLED, s); return this; }
    public Panel bullet(String s) { push(PanelElementType.BULLET_TEXT, s); return this; }

    public Panel colored(String s, int color) {
        PanelElement el = push(PanelElementType.TEXT_COLORED, s);
        el.color = color;
        return this;
    }

    public Panel status(String s) {
        return status(s, PanelTone.NEUTRAL);
    }

    public Panel status(String s, PanelTone tone) {
        PanelElement el = push(PanelElementType.TEXT_COLORED, s);
        el.intVal3 = (tone == null ? PanelTone.NEUTRAL.protocolId() : tone.protocolId()) + 1;
        return this;
    }

    public Panel label(String label, String value) {
        PanelElement el = push(PanelElementType.LABEL_TEXT, label);
        el.textSecondary = value == null ? "" : value;
        return this;
    }

    // --- Layout ---
    public Panel separator() { push(PanelElementType.SEPARATOR, ""); return this; }
    public Panel separatorText(String s) { push(PanelElementType.SEPARATOR_TEXT, s); return this; }
    public Panel section(String s) { return separatorText(s); }
    public Panel spacing() { push(PanelElementType.SPACING, ""); return this; }
    public Panel sameLine() { push(PanelElementType.SAME_LINE, ""); return this; }
    public Panel newLine() { push(PanelElementType.NEW_LINE, ""); return this; }
    public Panel indent() { push(PanelElementType.INDENT, ""); return this; }
    public Panel unindent() { push(PanelElementType.UNINDENT, ""); return this; }

    public Panel dummy(float width, float height) {
        PanelElement el = push(PanelElementType.DUMMY, "");
        el.widthVal = width;
        el.heightVal = height;
        return this;
    }

    // --- Interactive controls ---
    public Panel button(String label, int actionId) {
        return button(label, actionId, PanelButtonStyle.NORMAL, 0.0f, 0.0f);
    }

    public Panel button(String label, int actionId, PanelButtonStyle style) {
        return button(label, actionId, style, 0.0f, 0.0f);
    }

    public Panel button(String label, int actionId, PanelButtonStyle style,
                        float width, float height) {
        PanelElement el = push(PanelElementType.BUTTON, label);
        el.actionId = actionId;
        el.intVal3 = style == null ? PanelButtonStyle.NORMAL.protocolId() : style.protocolId();
        el.widthVal = width;
        el.heightVal = height;
        return this;
    }

    public Panel smallButton(String label, int actionId) {
        return smallButton(label, actionId, PanelButtonStyle.NORMAL);
    }

    public Panel smallButton(String label, int actionId, PanelButtonStyle style) {
        PanelElement el = push(PanelElementType.SMALL_BUTTON, label);
        el.actionId = actionId;
        el.intVal3 = style == null ? PanelButtonStyle.NORMAL.protocolId() : style.protocolId();
        return this;
    }

    public Panel primaryButton(String label, int actionId) {
        return primaryButton(label, actionId, -1.0f, 0.0f);
    }

    public Panel primaryButton(String label, int actionId, float width, float height) {
        return button(label, actionId, PanelButtonStyle.PRIMARY, width, height);
    }

    public Panel secondaryButton(String label, int actionId) {
        return secondaryButton(label, actionId, -1.0f, 0.0f);
    }

    public Panel secondaryButton(String label, int actionId, float width, float height) {
        return button(label, actionId, PanelButtonStyle.SECONDARY, width, height);
    }

    public Panel dangerButton(String label, int actionId) {
        return dangerButton(label, actionId, -1.0f, 0.0f);
    }

    public Panel dangerButton(String label, int actionId, float width, float height) {
        return button(label, actionId, PanelButtonStyle.DANGER, width, height);
    }

    public Panel selectable(String label, int actionId) {
        return selectable(label, actionId, false);
    }

    public Panel selectable(String label, int actionId, boolean selected) {
        PanelElement el = push(PanelElementType.SELECTABLE, label);
        el.actionId = actionId;
        el.boolVal = selected;
        return this;
    }

    public Panel checkbox(String label, int actionId, boolean value) {
        PanelElement el = push(PanelElementType.CHECKBOX, label);
        el.actionId = actionId;
        el.boolVal = value;
        return this;
    }

    public Panel sliderInt(String label, int actionId, int value, int minValue, int maxValue) {
        PanelElement el = push(PanelElementType.SLIDER_INT, label);
        el.actionId = actionId;
        el.intVal = value;
        el.intVal2 = minValue;
        el.intVal3 = maxValue;
        return this;
    }

    public Panel sliderFloat(String label, int actionId, float value, float minValue, float maxValue) {
        PanelElement el = push(PanelElementType.SLIDER_FLOAT, label);
        el.actionId = actionId;
        el.floatVal = value;
        el.floatVal2 = minValue;
        el.floatVal3 = maxValue;
        return this;
    }

    public Panel inputText(String label, int actionId, String value) {
        return inputText(label, actionId, NO_SUBMIT, value, PanelInputFlags.NONE);
    }

    public Panel inputText(String label, int actionId, String value, int flags) {
        return inputText(label, actionId, NO_SUBMIT, value, flags);
    }

    /// Same as {@link #inputText(String, int, String)} but additionally fires
    /// {@code submitActionId} when the user presses Enter inside the field.
    public Panel inputText(String label, int actionId, int submitActionId, String value) {
        return inputText(label, actionId, submitActionId, value, PanelInputFlags.NONE);
    }

    public Panel inputText(String label, int actionId, int submitActionId, String value, int flags) {
        PanelElement el = push(PanelElementType.INPUT_TEXT, label);
        el.actionId = actionId;
        el.intVal2 = submitActionId;
        el.intVal3 = flags;
        el.textSecondary = value == null ? "" : value;
        return this;
    }

    public Panel inputPassword(String label, int actionId, String value) {
        return inputText(label, actionId, value, PanelInputFlags.PASSWORD);
    }

    public Panel inputPassword(String label, int actionId, int submitActionId, String value) {
        return inputText(label, actionId, submitActionId, value, PanelInputFlags.PASSWORD);
    }

    // --- Progress ---
    public Panel progress(float fraction) {
        return progress(fraction, "");
    }

    public Panel progress(float fraction, String overlay) {
        PanelElement el = push(PanelElementType.PROGRESS_BAR, overlay);
        el.floatVal = fraction;
        return this;
    }

    // --- Tree / collapsing ---
    public Panel collapsing(String label) { push(PanelElementType.COLLAPSING_HEADER, label); return this; }
    public Panel beginCollapsible(String label) { return beginCollapsible(label, false); }
    public Panel beginCollapsible(String label, boolean defaultOpen) {
        PanelElement el = push(PanelElementType.COLLAPSING_HEADER, label);
        el.intVal3 = COLLAPSIBLE_BLOCK_MARKER;
        el.boolVal = defaultOpen;
        return this;
    }
    public Panel endCollapsible() {
        PanelElement el = push(PanelElementType.TREE_POP, "");
        el.intVal3 = COLLAPSIBLE_BLOCK_MARKER;
        return this;
    }
    public Panel treeNode(String label) { push(PanelElementType.TREE_NODE, label); return this; }
    public Panel treePop() { push(PanelElementType.TREE_POP, ""); return this; }

    // --- Tables ---
    public Panel beginTable(String id, int columns) {
        return beginTable(id, columns, 0);
    }

    public Panel beginTable(String id, int columns, int flags) {
        PanelElement el = push(PanelElementType.BEGIN_TABLE, id);
        el.intVal = columns;
        el.intVal2 = flags;
        return this;
    }

    public Panel endTable() { push(PanelElementType.END_TABLE, ""); return this; }
    public Panel tableNextRow() { push(PanelElementType.TABLE_NEXT_ROW, ""); return this; }
    public Panel tableNextColumn() { push(PanelElementType.TABLE_NEXT_COLUMN, ""); return this; }
    public Panel tableHeadersRow() { push(PanelElementType.TABLE_HEADERS_ROW, ""); return this; }

    public Panel tableSetupColumn(String label) {
        return tableSetupColumn(label, 0, 0.0f);
    }

    public Panel tableSetupColumn(String label, int flags, float width) {
        PanelElement el = push(PanelElementType.TABLE_SETUP_COLUMN, label);
        el.intVal = flags;
        el.floatVal = width;
        return this;
    }

    // --- Tooltip on previous item ---
    public Panel tooltip(String t) { push(PanelElementType.SET_TOOLTIP, t); return this; }

    // --- Groups / child regions ---
    public Panel beginGroup() { push(PanelElementType.BEGIN_GROUP, ""); return this; }
    public Panel endGroup() { push(PanelElementType.END_GROUP, ""); return this; }

    /// Child-region flags for {@link #beginChild}. Combine with bitwise OR.
    public static final int CHILD_BORDER = 1;
    public static final int CHILD_PADDING = 2;
    public static final int CHILD_AUTO_RESIZE_Y = 4;
    public static final int CHILD_FRAME = 8;

    public Panel beginChild(String id) { return beginChild(id, 0, 0.0f, 0.0f); }
    public Panel beginChild(String id, int childFlags) { return beginChild(id, childFlags, 0.0f, 0.0f); }
    public Panel beginChild(String id, int childFlags, float width, float height) {
        PanelElement el = push(PanelElementType.BEGIN_CHILD, id);
        el.intVal2 = childFlags;
        el.widthVal = width;
        el.heightVal = height;
        return this;
    }
    public Panel endChild() { push(PanelElementType.END_CHILD, ""); return this; }

    /// Framed, padded, auto-height "card" container. Pair with {@link #endCard}.
    public Panel beginCard(String id) {
        return beginChild(id, CHILD_FRAME | CHILD_AUTO_RESIZE_Y | CHILD_PADDING, 0.0f, 0.0f);
    }
    public Panel endCard() { push(PanelElementType.END_CHILD, ""); return this; }

    /// Horizontal alignment for {@link #beginAlign}.
    public enum Align {
        LEFT(0), CENTER(1), RIGHT(2);
        private final int protocolId;
        Align(int id) { this.protocolId = id; }
        public int protocolId() { return protocolId; }
    }

    /// Center/right-align a same-line run of buttons within the content width.
    /// Emit the buttons (with {@link #sameLine()} between) between
    /// {@code beginAlign()} and {@link #endAlign()}.
    public Panel beginAlign(Align align) {
        PanelElement el = push(PanelElementType.ALIGN_BEGIN, "");
        el.intVal = align == null ? 0 : align.protocolId();
        return this;
    }
    public Panel endAlign() { push(PanelElementType.ALIGN_END, ""); return this; }

    /// Raw escape hatch: append a custom element directly and return it so
    /// extra fields can be set in place.
    public PanelElement push(PanelElementType type, String text) {
        PanelElement el = new PanelElement(type, text);
        elements.add(el);
        return el;
    }

    /// The accumulated command list (read-only). Consumed by the runtime.
    public List<PanelElement> elements() {
        return Collections.unmodifiableList(elements);
    }

    private static final int NO_SUBMIT = -1;
    private static final int COLLAPSIBLE_BLOCK_MARKER = 0x54434F4C;
}
