package net.titan.api;

import net.titan.api.internal.TitanRuntime;
import net.titan.api.queries.WidgetQuerySnapshot;

import java.util.Optional;
import java.util.OptionalInt;
import java.util.OptionalLong;
import java.util.List;

public interface Client {
    /** Java SDK 0.1.94: whether the loaded client has validated menu editing support. */
    default boolean isMenuEditingAvailable() { return false; }
    /** True only within a synchronous menu edit window on the game thread. */
    default boolean isMenuEditable() { return false; }
    default boolean isMenuOpen() { return false; }
    /** Current root entries in bottom-to-top order. Older hosts return an empty array. */
    default MenuEntry[] getMenuEntries() { return new MenuEntry[0]; }
    /** Reorder siblings and optionally remove leaves, atomically. No reparenting. */
    default void setMenuEntries(MenuEntry[] entries) {
        throw new IllegalStateException("Menu editing is unavailable");
    }
    /** Insert a custom root entry. -1 appends at the top; other negatives count from the end. */
    default MenuEntry createMenuEntry(int index) {
        throw new IllegalStateException("Menu editing is unavailable");
    }
    default void swapMenuEntries(int first, int second) {
        MenuEntry[] entries = getMenuEntries();
        if (first < 0 || second < 0 || first >= entries.length || second >= entries.length)
            throw new IndexOutOfBoundsException("Menu entry index");
        MenuEntry swap = entries[first]; entries[first] = entries[second]; entries[second] = swap;
        setMenuEntries(entries);
    }
    /** Remove a leaf entry from this generation. Submenu parents cannot be removed. */
    default void removeMenuEntry(MenuEntry entry) {
        throw new IllegalStateException("Menu editing is unavailable");
    }
    /** SDK 148: unavailable is empty; an available snapshot may have zero entries. Game-thread read. */
    default Optional<HintArrowSnapshot> hintArrows() { return Optional.empty(); }
    /** Set server slot zero at the tile center. The native-selected WorldView and plane must match. */
    default HintArrowUpdateResult setHintArrow(WorldPoint point) {
        return setHintArrow(point, 64, 64, 0);
    }
    /** SDK 148: synchronous game-thread write; sub-tile units are 1/128 tile and height is native units. */
    default HintArrowUpdateResult setHintArrow(WorldPoint point, int subX, int subY, int height) {
        return HintArrowUpdateResult.UNAVAILABLE;
    }
    /** Set server slot zero to an existing NPC/player, revalidating the full actor identity. */
    default HintArrowUpdateResult setHintArrow(Actor actor) { return HintArrowUpdateResult.UNAVAILABLE; }
    /** Clear server slot zero. Subsequent server updates can replace locally written state. */
    default HintArrowUpdateResult clearHintArrow() { return HintArrowUpdateResult.UNAVAILABLE; }
    int tick();
    /**
     * Current signed 32-bit native Client.GameCycle. This clock advances at
     * the nominal 20 ms client logic cadence; 30 cycles make one 600 ms
     * server tick. It is distinct from {@link #tick()}. Added in SDK 125.
     */
    /** SDK 127: bit 1 direct reads; bit 2 all five utterance sources installed. */
    default int getOverheadTextCapabilities() { return 0; }
    int gameCycle();
    int plane();
    int localPlayerIndex();
    int playerCount();
    int baseX();
    int baseY();
    int sceneSizeX();
    int sceneSizeY();
    int runEnergy();
    int weight();
    boolean loggedIn();
    int currentWorldViewId();
    int topLevelBaseX();
    int topLevelBaseY();
    int topLevelPlane();
    int topLevelSceneSizeX();
    int topLevelSceneSizeY();
    int topLevelLocalPlayerTileX();
    int topLevelLocalPlayerTileY();
    int topLevelLocalPlayerPlane();
    boolean topLevelLocalPlayerTileValid();
    default int accountType() { return varbit(Varbits.ACCOUNT_TYPE); }
    default boolean isIronman() {
        int type = accountType();
        return type >= 1 && type <= 6;
    }
    default boolean isIronMan() { return isIronman(); }
    default boolean isGroupIronman() {
        int type = accountType();
        return type == 4 || type == 5 || type == 6;
    }
    default boolean isGroupIronMan() { return isGroupIronman(); }
    OptionalLong currentWorldViewPtr();
    OptionalLong worldViewPtr(int worldViewId);
    OptionalLong topLevelWorldViewPtr();
    boolean isInInstance();
    Optional<int[][][]> instanceTemplateChunks();
    Optional<WorldPoint> fromLocalInstance(WorldPoint point);
    Optional<WorldPoint> toLocalInstance(WorldPoint point);
    Optional<LocalPoint> getLocalDestinationLocation();
    Optional<WorldPoint> getWorldDestinationLocation();
    Optional<Player> localPlayer();
    List<Player> players();
    List<NPC> npcs();
    List<TileObject> tileObjects(int radius);
    default List<TileObject> tileObjects() { return tileObjects(10); }
    List<TileObject> tileObjectsOnTile(int plane, int tileX, int tileY);
    default List<TileObject> tileObjectsOnTile(Tile tile) {
        return tile == null
            ? java.util.Collections.emptyList()
            : tileObjectsOnTile(tile.plane(), tile.x(), tile.y());
    }
    default List<TileObject> tileObjectsOnTile(Locatable<?> locatable) {
        return locatable == null
            ? java.util.Collections.emptyList()
            : tileObjectsOnTile(locatable.plane(), locatable.tileX(), locatable.tileY());
    }
    List<GroundItem> groundItems(int radius);
    default List<GroundItem> groundItems() { return groundItems(10); }
    List<GroundItem> groundItemsOnTile(int plane, int tileX, int tileY);
    default List<GroundItem> groundItemsOnTile(Tile tile) {
        return tile == null
            ? java.util.Collections.emptyList()
            : groundItemsOnTile(tile.plane(), tile.x(), tile.y());
    }
    default List<GroundItem> groundItemsOnTile(Locatable<?> locatable) {
        return locatable == null
            ? java.util.Collections.emptyList()
            : groundItemsOnTile(locatable.plane(), locatable.tileX(), locatable.tileY());
    }
    List<Projectile> projectiles();
    List<GraphicsObject> graphicsObjects();
    Optional<Camera> camera();
    Optional<ScreenPoint> mousePosition();
    Optional<ScreenPoint> worldToScreen(int worldX, int worldY, int worldZ);
    default Optional<ScreenPoint> worldToScreen(WorldPoint point) {
        return point == null
            ? Optional.empty()
            : worldToScreen(point.x(), point.y(), point.z());
    }
    default Optional<ScreenPoint> worldToScreen(Locatable<?> locatable) {
        return locatable == null
            ? Optional.empty()
            : worldToScreen(locatable.worldX(), locatable.worldY(), locatable.plane());
    }
    Optional<ScreenPoint> worldToScreenInWorldView(int worldViewId,
                                                   int preciseX,
                                                   int worldY,
                                                   int preciseY,
                                                   int plane);
    default Optional<ScreenPoint> worldToScreen(LocalPoint point, int worldY, int plane) {
        return point == null
            ? Optional.empty()
            : worldToScreenInWorldView(point.worldViewId(), point.x(), worldY, point.y(), plane);
    }
    default Optional<ScreenPoint> worldToScreen(Locatable<?> locatable, int worldY) {
        return locatable == null
            ? Optional.empty()
            : worldToScreen(locatable.localPoint(), worldY, locatable.plane());
    }
    Optional<ScreenPoint> tileToScreen(int tileX, int tileY, int plane, int heightOffset);
    default Optional<ScreenPoint> tileToScreen(Tile tile, int heightOffset) {
        return tile == null
            ? Optional.empty()
            : tileToScreen(tile.x(), tile.y(), tile.plane(), heightOffset);
    }
    int tileHeight(int preciseX, int preciseY, int plane);
    int tileHeightInWorldView(int worldViewId, int preciseX, int preciseY, int plane);
    default int tileHeight(LocalPoint point, int plane) {
        return point == null ? 0 : tileHeightInWorldView(point.worldViewId(), point.x(), point.y(), plane);
    }
    default int worldTileHeightInWorldView(int worldViewId, int worldTileX, int worldTileY, int plane) {
        int baseX = worldViewId == WorldView.TOP_LEVEL ? topLevelBaseX() : baseX();
        int baseY = worldViewId == WorldView.TOP_LEVEL ? topLevelBaseY() : baseY();
        return tileHeightInWorldView(worldViewId, (worldTileX - baseX) * 128,
                                     (worldTileY - baseY) * 128, plane);
    }

    int varbit(int id);
    int varp(int id);
    OptionalInt varClientInt(int id);
    boolean setVarClientInt(int id, int value);
    Optional<String> varClientString(int id);
    boolean setVarClientString(int id, String value);
    OptionalLong varClientLong(int id);
    boolean setVarClientLong(int id, long value);

    boolean prayerActive(int prayerOrdinal);
    int boostedSkillLevel(int skillId);
    int realSkillLevel(int skillId);
    int skillExperience(int skillId);
    default int boostedSkillLevel(Skill skill) { return boostedSkillLevel(skill.id()); }
    default int realSkillLevel(Skill skill) { return realSkillLevel(skill.id()); }
    default int skillExperience(Skill skill) { return skillExperience(skill.id()); }

    int collisionFlag(int plane, int tileX, int tileY);
    default int collisionFlag(Tile tile) {
        return tile == null ? 0 : collisionFlag(tile.plane(), tile.x(), tile.y());
    }
    default int collisionFlag(Locatable<?> locatable) {
        return locatable == null ? 0
            : collisionFlag(locatable.plane(), locatable.tileX(), locatable.tileY());
    }
    boolean entityHidden(int entityType);
    boolean setEntityHidden(int entityType, boolean hidden);

    /**
     * Whether global sound-effect playback is currently suppressed. Added in
     * SDK 69.
     */
    boolean audioPlaybackDisabled();

    /** SDK 156: thread-safe, process-wide classic actor smoothing; default off.
     * Unsupported poses continue to use native rendering. */
    default boolean isAnimationSmoothingAvailable() { return false; }
    /** Last request wins, not saved; disable when the plugin stops. Acceptance
     * does not guarantee every pose can be smoothed. Safe from any thread. */
    default boolean setAnimationSmoothingEnabled(boolean enabled) { return false; }
    default boolean getAnimationSmoothingEnabledRequested() { return false; }
    /** Whether the smoothing path is enabled, not whether every pose is supported. */
    default boolean getAnimationSmoothingEnabledApplied() { return false; }
    /** 0=None, 1=Unavailable, 2=InstallFailed, 3=ShuttingDown. */
    default int getAnimationSmoothingError() { return 1; }

    /** SDK 150: thread-safe texture capability. */
    default boolean isTextureSkippingAvailable() { return false; }
    /** Queues a runtime request; accepted does not mean applied. Last writer wins;
     * does not save preferences or restore an earlier value on plugin unload.
     * Safe from callbacks and plugin-owned workers. */
    default boolean setTexturesDisabled(boolean disabled) { return false; }
    default boolean getTexturesDisabledRequested() { return false; }
    default boolean getTexturesDisabledApplied() { return false; }
    /** 0=None, 1=Unavailable, 2=InstallFailed, 3=RemoveFailed, 4=ProviderReadFailed,
     * 5=CacheResetFailed, 6=DirtyWriteFailed, 7=ShuttingDown. */
    default int getTextureSkippingError() { return 1; }

    /** SDK 151: whether this client can render only the local player's plane. */
    default boolean planeHidingAvailable() { return false; }
    /** SDK 151: whether every plane except the local player's is hidden. */
    default boolean otherPlanesHidden() { return false; }
    /** SDK 151: render only the local player's plane (floors above and below
     * are hidden). Process-wide, last writer wins, not saved, and it stays on
     * after the plugin unloads, so turn it off when the plugin stops. Safe from
     * any thread. Returns false when the client cannot hide planes. */
    default boolean setOtherPlanesHidden(boolean hidden) { return false; }

    /**
     * Globally suppress (or re-enable) sound playback. When disabled, the
     * sound hooks still fire {@code onSoundPlayed} but skip the native playback
     * call. Per-sound playback suppression is not supported by the current
     * hook; {@code event.consume()} only affects handler ordering. Added in
     * SDK 69.
     *
     * @return true if the toggle request was accepted.
     */
    boolean setAudioPlaybackDisabled(boolean disabled);
    boolean walkTo(int sceneX, int sceneY);
    boolean walkToWorld(int worldX, int worldY, int plane);
    default boolean walkTo(WorldPoint point) {
        return point != null && walkToWorld(point.x(), point.y(), point.z());
    }
    default boolean walkTo(Locatable<?> locatable) {
        return locatable != null && walkToWorld(
            locatable.worldX(), locatable.worldY(), locatable.plane());
    }
    boolean invokeMenuAction(long opcode, int identifier, int param0, int param1,
                             long worldViewId, int clickX, int clickY,
                             String actionText, String targetText, boolean skipClick);
    /** SDK 128. Queue source opcode 25 and its dependent target together.
     * Null expectedSourceItemId binds the source widget's live item on the game thread.
     * Default false keeps older backend implementations safe. True means queued. */
    default boolean invokeSelectedMenuAction(MenuActionRequest source, MenuActionRequest target,
                                             Integer expectedSourceItemId) { return false; }
    default boolean invokeSelectedMenuAction(MenuActionRequest source, MenuActionRequest target) {
        return invokeSelectedMenuAction(source, target, null);
    }
    boolean interactNpc(String action, int npcIdOrNeg1, String nameOrNull);
    @Deprecated
    default boolean interactNpcByIndex(String action, int hashIndex) {
        return TitanRuntime.getInteractionBackend().interactNpcByIndex(action, hashIndex);
    }
    default boolean interactNpcByIndex(String action, int hashIndex, int worldViewId) {
        return TitanRuntime.getInteractionBackend().interactNpcByIndex(action, hashIndex, worldViewId);
    }
    boolean interactObject(String action, int locIdOrNeg1, String nameOrNull);
    @Deprecated
    default boolean interactTileObject(String action, TileObject object) {
        return TitanRuntime.getInteractionBackend().interactTileObject(action, object);
    }
    @Deprecated
    default boolean interactGroundItem(String action, int itemId, int tileX, int tileY) {
        return TitanRuntime.getInteractionBackend().interactGroundItem(action, itemId, tileX, tileY);
    }
    default boolean interactGroundItem(String action, int itemId, int tileX, int tileY,
                                       int worldViewId) {
        return TitanRuntime.getInteractionBackend().interactGroundItem(
            action, itemId, tileX, tileY, worldViewId);
    }
    Optional<NPC> findNearestNpc(int npcIdOrNeg1, String nameOrNull);
    default Optional<NPC> findNearestNpc(int npcId) {
        return findNearestNpc(npcId, null);
    }
    default Optional<NPC> findNearestNpc(String name) {
        return findNearestNpc(-1, name);
    }
    Optional<TileObject> findNearestObject(int locIdOrNeg1, String nameOrNull);
    default Optional<TileObject> findNearestObject(int locId) {
        return findNearestObject(locId, null);
    }
    default Optional<TileObject> findNearestObject(String name) {
        return findNearestObject(-1, name);
    }

    List<InventoryItem> inventoryItems();
    boolean containsInventoryItem(int itemId);
    @Deprecated
    default boolean interactInventoryItem(int itemId, String action) {
        return TitanRuntime.getInteractionBackend().interactInventoryItem(itemId, action);
    }
    @Deprecated
    default boolean interactInventoryItemAtSlot(int slot, int itemId, String action) {
        return TitanRuntime.getInteractionBackend().interactInventoryItemAtSlot(slot, itemId, action);
    }
    @Deprecated
    default boolean useInventoryItemOnItem(int srcSlot, int srcItemId,
                                           int targetSlot, int targetItemId) {
        return TitanRuntime.getInteractionBackend().useInventoryItemOnItem(
            srcSlot, srcItemId, targetSlot, targetItemId);
    }
    @Deprecated
    default boolean useInventoryItemOnNpc(int srcSlot, int srcItemId, int npcHashIndex) {
        return TitanRuntime.getInteractionBackend().useInventoryItemOnNpc(
            srcSlot, srcItemId, npcHashIndex);
    }
    @Deprecated
    default boolean useInventoryItemOnObject(int srcSlot, int srcItemId,
                                             int objectId, int tileX, int tileY) {
        return TitanRuntime.getInteractionBackend().useInventoryItemOnObject(
            srcSlot, srcItemId, objectId, tileX, tileY);
    }
    /** Immutable snapshots in zero-based slot order, including empty slots.
     * Returns an empty list when data is unavailable or queued offer callbacks
     * have not finished delivery. Owned event payloads remain usable. */
    default List<GrandExchangeOffer> getGrandExchangeOffers() {
        return java.util.Collections.emptyList();
    }
    /** Empty when the slot is invalid or the native snapshot is unavailable. */
    default Optional<GrandExchangeOffer> getGrandExchangeOffer(int slot) {
        if (slot < 0) return Optional.empty();
        return getGrandExchangeOffers().stream().filter(offer -> offer.slot() == slot).findFirst();
    }
    /** Whether validated full Grand Exchange data is available and queued offer
     * callbacks have finished delivery. */
    default boolean isGrandExchangeAvailable() { return false; }

    /** SDK 139. Bindings for the shared C++ GE queue; no plugin context is required. */
    default long geSubmitBuy(GeBuyOptions options) { return 0; }
    default List<GeRequest> geRequests(long id) { return java.util.Collections.emptyList(); }
    default boolean geCancelRequest(long id) { return false; }
    default boolean geReleaseRequest(long id) { return false; }

    /** @deprecated The queue is shared; the legacy owner argument is ignored. */
    @Deprecated default long geSubmitBuy(String ignored, GeBuyOptions options) { return geSubmitBuy(options); }
    /** @deprecated Use {@link #geRequests(long)}. */
    @Deprecated default List<GeRequest> geRequests(String ignored, long id) { return geRequests(id); }
    /** @deprecated Use {@link #geCancelRequest(long)}. */
    @Deprecated default boolean geCancelRequest(String ignored, long id) { return geCancelRequest(id); }
    /** @deprecated Use {@link #geReleaseRequest(long)}. */
    @Deprecated default boolean geReleaseRequest(String ignored, long id) { return geReleaseRequest(id); }

    /** SDK 138. Empty optional means unsupported; an unknown bank has known=false. */
    default Optional<BankCacheSnapshot> getItemCacheBank() { return Optional.empty(); }
    /** Client-wide public Wiki metadata and price cache (SDK 137). */
    default ItemPrices itemPrices() { return Titan.itemPrices(); }

    Optional<ItemContainer> itemContainer(int containerId);
    Optional<ItemComposition> itemComposition(int itemId);

    /**
     * Whether a spell or an item selected with Use is currently selected for
     * targeting, matching RuneLite's selection flag. This can remain true
     * even when the selected widget no longer resolves. False on older hosts
     * or when selection state is unavailable.
     */
    default boolean isWidgetSelected() { return false; }

    /**
     * The selected spell or Use-item widget, or null when selection is
     * inactive, unavailable, or its widget no longer resolves. Matches
     * RuneLite's nullable result: child index -1 returns the base widget;
     * nonnegative indices return the exact dynamic child. The returned live
     * widget retains that address for later reads and interactions.
     */
    default Widget getSelectedWidget() { return null; }

    Optional<Widget> widget(int packedId);
    List<Widget> widgets(int groupId);
    default List<Widget> widgets() { return widgets(-1); }
    default WidgetQuerySnapshot widgetQuery(int groupId) {
        return new WidgetQuerySnapshot(widgets(groupId), false);
    }
    List<Widget> widgetChildren(int parentPackedId);
    List<Widget> widgetChildrenAtPath(WidgetAddress address);
    /**
     * This default composes from {@link #widgetChildrenAtPath(WidgetAddress)},
     * which carries no truncation information, so it always reports
     * {@code truncated == false}. The runtime {@code HostBridge} override
     * reports the host's real truncation flag.
     */
    default WidgetQuerySnapshot widgetChildrenQueryAtPath(WidgetAddress address) {
        return new WidgetQuerySnapshot(widgetChildrenAtPath(address), false);
    }
    Optional<Widget> widgetByText(String query);
    @Deprecated
    default boolean widgetInteract(int opcode, int identifier, int param0, int param1) {
        return TitanRuntime.getInteractionBackend().widgetInteract(opcode, identifier, param0, param1);
    }
    @Deprecated
    default boolean widgetInteractAtPath(WidgetAddress address, int opcode,
                                         int identifier, int childSlot) {
        return TitanRuntime.getInteractionBackend().widgetInteractAtPath(
            address, opcode, identifier, childSlot);
    }
    @Deprecated
    default boolean setWidgetText(int packedId, String text) {
        return TitanRuntime.getInteractionBackend().setWidgetText(packedId, text);
    }
    @Deprecated
    default boolean setWidgetTextAtPath(WidgetAddress address, String text) {
        return TitanRuntime.getInteractionBackend().setWidgetTextAtPath(address, text);
    }

    OptionalInt currentWorld();
    List<World> worlds();
    List<WorldMetadata> worldMetadata();
    boolean refreshWorldMetadata();
    boolean hopToWorldId(int worldId);
    boolean hopToWorldIngame(int worldId);
    boolean hopToListIndex(int listIndex);

    int idleTimeRemaining();
    void resetIdleTimer();

    int questState(int questId);

    // --- CS2 client scripts ---
    Optional<Cs2Result> runClientScript(int scriptId, int[] intArgs);
    default Optional<Cs2Result> runClientScript(int scriptId) {
        return runClientScript(scriptId, new int[0]);
    }
    default OptionalInt runClientScriptForInt(int scriptId, int[] intArgs) {
        return runClientScript(scriptId, intArgs)
            .filter(Cs2Result::success)
            .map(Cs2Result::firstInt)
            .orElse(OptionalInt.empty());
    }

    // --- Cache definition lookups ---
    Optional<ItemDefinition> itemDefinition(int itemId);
    Optional<NPCDefinition> npcDefinition(int npcId);
    Optional<ObjectDefinition> objectDefinition(int objectId);
    Optional<VarbitDefinition> varbitDefinition(int varbitId);

    // --- Plugin manager ---
    List<PluginInfo> plugins();
    Optional<PluginInfo> plugin(String pluginId);
    boolean setPluginEnabled(String pluginId, boolean enabled);
    /// 1 = enabled, 0 = disabled, -1 = unknown id.
    int pluginEnabledState(String pluginId);

    // --- Login / account state ---
    Optional<LoginState> loginState();
    boolean setLoginUsername(String username);
    boolean setLoginPassword(String password);
    boolean setLoginAuthenticator(String code);
    boolean setLoginIndex(int loginIndex);
    boolean setLoginDisplayName(String displayName);
    boolean setLoginOAuth2Credentials(String accessToken, String refreshToken);
    boolean setLoginGameSessionCredentials(String sessionId, String characterId);
    boolean setLoginCharacter(String displayName, String characterId, String sessionId);
    boolean resetLoginCharacter();
    boolean stageLoginCredentials(String profileName);
    boolean submitLoginCredentials();

    boolean addChatMessage(int type, String name, String message, String sender);
    boolean sendKeyboardString(String text);
    boolean sendKeyboardKey(int key, int modifiers);
    default boolean sendKeyboardKey(int key) { return sendKeyboardKey(key, 0); }

    // --- Human-like delayed keyboard typing ---
    /**
     * Starts human-like typing on the game thread. Returns {@code false}, and
     * types nothing, when the keyboard subsystem is unavailable or while the
     * embedded runtime is resetting or stopping (no keystrokes are injected on
     * behalf of a plugin that is being unloaded). In that case the callback
     * overload never invokes its callback.
     */
    boolean typeKeyboardString(String text);
    boolean typeKeyboardString(String text, int minDelayMs, int maxDelayMs);
    boolean typeKeyboardString(String text, int minDelayMs, int maxDelayMs,
                               int callbackPhase, KeyboardTypeCallback callback);
    void cancelKeyboardType();
    boolean isKeyboardTyping();
}
