package net.titan.gamevals.internal;

import java.util.Optional;

import net.titan.gamevals.GamevalEntry;
import net.titan.gamevals.QuestEntry;

final class InventoryIDEntries_2 {
    private InventoryIDEntries_2() {}

    static GamevalEntry[] entries() {
        return new GamevalEntry[] {
            new GamevalEntry(1024, "SKILLING_MODE_HOLDING_INV", "skilling_mode_holding_inv", "invtypes"),
            new GamevalEntry(1025, "PUB_BURGH_DE_ROTT", "pub_burgh_de_rott", "invtypes"),
            new GamevalEntry(1026, "WYRMSCRAIG_GENERAL_SHOP", "wyrmscraig_general_shop", "invtypes"),
            new GamevalEntry(1027, "WYRMSCRAIG_CLOTHES_SHOP", "wyrmscraig_clothes_shop", "invtypes"),
            new GamevalEntry(1028, "LANSCAPE_GARY_GILBERT_FINALE_SHOP", "lanscape_gary_gilbert_finale_shop", "invtypes"),
            new GamevalEntry(1029, "TFA_CHESTS", "tfa_chests", "invtypes"),
            new GamevalEntry(1030, "TFA_MIDRAID_SUPPLIES_SHOP", "tfa_midraid_supplies_shop", "invtypes"),
            new GamevalEntry(1031, "TFA_SUPPLIES_SNAPSHOT_INV", "tfa_supplies_snapshot_inv", "invtypes"),
            new GamevalEntry(1032, "LUMBRIDGE_BLACKSMITH", "lumbridge_blacksmith", "invtypes"),
            new GamevalEntry(1033, "RENDER_WORN", "render_worn", "invtypes"),
            new GamevalEntry(1034, "PUB_LUMBRIDGE", "pub_lumbridge", "invtypes"),
        };
    }

    static Optional<GamevalEntry> byId(int id) {
        for (GamevalEntry entry : entries()) {
            if (entry.id() == id) return Optional.of(entry);
        }
        return Optional.empty();
    }

}
