package net.titan.api.utils;

import net.titan.api.BankSets;
import net.titan.api.Client;
import net.titan.api.InventoryId;
import net.titan.api.InventoryItem;
import net.titan.api.ItemContainer;
import net.titan.api.ItemCache;
import net.titan.api.MenuAction;
import net.titan.api.Player;
import net.titan.api.TileObject;
import net.titan.api.Titan;
import net.titan.api.Varbits;
import net.titan.api.Widget;
import net.titan.api.internal.InteractionBackend;
import net.titan.api.internal.TitanRuntime;
import net.titan.api.queries.Queries;
import net.titan.gamevals.InterfaceID;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/// Plugin-side bank state, query, action, and PIN helpers. Mirrors the C++
/// {@code titan::utils::Bank} surface (open/close, deposit/withdraw, PIN,
/// near-bank), composing existing {@link Client}/widget/query calls.
public final class Bank {
    private Bank() {}

    /// Interface group of the bank PIN keypad (213).
    private static final int BANKPIN_KEYPAD_GROUP =
        InterfaceID.BankpinKeypad.UNIVERSE >>> 16;

    private static Client client() {
        return Titan.client();
    }

    private static InteractionBackend actions() {
        return TitanRuntime.getInteractionBackend();
    }

    // --- State reads -----------------------------------------------------

    public static boolean isOpen() {
        return widgetVisible(InterfaceID.Bankmain.ITEMS);
    }

    public static boolean isGeOpen() {
        return widgetVisible(InterfaceID.GeOffersSide.ITEMS);
    }

    /// True while the chatbox modal input line is up -- the Withdraw-X
    /// "Enter amount:" prompt or the bank search's "Enter name:" prompt.
    ///
    /// Structural, not textual: a text scan matches hidden widgets that still
    /// hold the previous prompt's text, so it latches true once the first
    /// prompt has closed.
    public static boolean isSearchOpen() {
        return widgetVisible(InterfaceID.Chatbox.MES_TEXT2);
    }

    public static boolean isNotedMode() {
        return client().varbit(Varbits.BANK_WITHDRAWNOTES) == 1;
    }

    public static int getBankTab() {
        return client().varbit(Varbits.CURRENT_BANK_TAB);
    }

    public static boolean isMainTabOpen() {
        return getBankTab() == 0;
    }

    // --- Bank container queries ------------------------------------------

    /** Live open bank, then the C++ host's remembered bank, then empty. */
    public static List<InventoryItem> getAll() {
        if (isOpen()) {
            Optional<ItemContainer> live = client().itemContainer(InventoryId.BANK);
            // A present but empty live bank must not resurrect remembered stock.
            if (live.isPresent()) return live.get().items().stream()
                .filter(item -> item.quantity() > 0)
                .collect(Collectors.toUnmodifiableList());
        }
        return ItemCache.getBankItems();
    }

    public static boolean contains(int itemId) {
        return find(itemId).isPresent();
    }

    public static boolean contains(String name) {
        return find(name).isPresent();
    }

    public static boolean contains(int itemId, int minQuantity) {
        return count(itemId) >= minQuantity;
    }

    public static int count(int itemId) {
        int total = 0;
        for (InventoryItem item : getAll()) {
            if (item.id() == itemId) total += item.quantity();
        }
        return total;
    }

    public static int count(String name) {
        int total = 0;
        for (InventoryItem item : getAll()) {
            if (containsIgnoreCase(itemName(item), name)) total += item.quantity();
        }
        return total;
    }

    public static Optional<InventoryItem> find(int itemId) {
        for (InventoryItem item : getAll()) {
            if (item.id() == itemId && item.quantity() > 0) return Optional.of(item);
        }
        return Optional.empty();
    }

    public static Optional<InventoryItem> find(String name) {
        for (InventoryItem item : getAll()) {
            if (item.quantity() > 0 && containsIgnoreCase(itemName(item), name)) return Optional.of(item);
        }
        return Optional.empty();
    }

    // --- Actions ---------------------------------------------------------

    public static boolean close() {
        return actions().widgetInteract(MenuAction.CC_OP, 1, 11, InterfaceID.Bankmain.FRAME);
    }

    public static boolean setNotedMode(boolean noted) {
        if (isNotedMode() == noted) return true;
        return actions().widgetInteract(
            MenuAction.CC_OP, 1, -1, InterfaceID.Bankmain.POTIONSTORE_CONTAINER);
    }

    public static boolean depositAll() {
        return actions().widgetInteract(
            MenuAction.CC_OP, 1, -1, InterfaceID.Bankmain.DEPOSITINV);
    }

    public static boolean depositEquipment() {
        return actions().widgetInteract(
            MenuAction.CC_OP, 1, -1, InterfaceID.Bankmain.DEPOSITWORN);
    }

    /** Activate the bank's Deposit containers button. */
    public static boolean depositContainers() {
        return actions().widgetInteract(
            MenuAction.CC_OP, 1, -1, InterfaceID.Bankmain.DEPOSITCONTAINERS);
    }

    public static boolean depositAllOfSlot(int slot) {
        return actions().widgetInteract(
            MenuAction.CC_OP_LOW_PRIORITY, 8, slot,
            InterfaceID.Bankside.ITEMS);
    }

    public static boolean depositOneOfSlot(int slot) {
        int qty = bankQuantityType();
        int identifier = (qty == 0) ? 2 : 3;
        return actions().widgetInteract(
            MenuAction.CC_OP, identifier, slot,
            InterfaceID.Bankside.ITEMS);
    }

    public static boolean depositAllOfItem(int itemId) {
        return inventorySlotOf(itemId).map(Bank::depositAllOfSlot).orElse(false);
    }

    public static boolean depositOneOfItem(int itemId) {
        return inventorySlotOf(itemId).map(Bank::depositOneOfSlot).orElse(false);
    }

    public static boolean depositAllExcept(int... keepIds) {
        Optional<ItemContainer> inv = client().itemContainer(InventoryId.INVENTORY);
        if (inv.isEmpty()) return false;
        for (InventoryItem item : inv.get().items()) {
            boolean keep = false;
            if (keepIds != null) {
                for (int kid : keepIds) {
                    if (item.id() == kid) { keep = true; break; }
                }
            }
            if (!keep) return depositAllOfSlot(item.slot());
        }
        return false;
    }

    private static Optional<InventoryItem> findLive(int itemId) {
        if (!isOpen()) return Optional.empty();
        return client().itemContainer(InventoryId.BANK).flatMap(bank -> bank.items().stream()
            .filter(item -> item.id() == itemId && item.quantity() > 0).findFirst());
    }

    public static boolean withdrawItem(int itemId) {
        Optional<InventoryItem> slot = findLive(itemId);
        if (slot.isEmpty()) return false;
        int qty = bankQuantityType();
        int identifier = (qty == 0) ? 1 : 2;
        return actions().widgetInteract(
            MenuAction.CC_OP, identifier, slot.get().slot(),
            InterfaceID.Bankmain.ITEMS);
    }

    public static boolean withdrawAllItem(int itemId) {
        Optional<InventoryItem> slot = findLive(itemId);
        if (slot.isEmpty()) return false;
        int qty = bankQuantityType();
        int identifier = (qty == 4) ? 1 : 7;
        int op = (qty == 4) ? MenuAction.CC_OP : MenuAction.CC_OP_LOW_PRIORITY;
        return actions().widgetInteract(op, identifier, slot.get().slot(),
            InterfaceID.Bankmain.ITEMS);
    }

    /// Withdraw a specific amount. For 1/5/10 the matching menu option is used.
    /// For other amounts: if BANK_REQUESTEDQUANTITY already equals {@code amount}
    /// the fast path is clicked; otherwise Withdraw-X is clicked and {@code true}
    /// is returned so the caller can type the amount once {@link #isSearchOpen()}.
    public static boolean withdrawItemAmount(int itemId, int amount) {
        Optional<InventoryItem> found = findLive(itemId);
        if (found.isEmpty()) return false;
        int slot = found.get().slot();
        int qty = bankQuantityType();

        if (amount == 1) {
            int id = (qty == 0) ? 1 : 2;
            return actions().widgetInteract(MenuAction.CC_OP, id, slot,
                InterfaceID.Bankmain.ITEMS);
        }
        if (amount == 5) {
            int id = (qty == 1) ? 1 : 3;
            return actions().widgetInteract(MenuAction.CC_OP, id, slot,
                InterfaceID.Bankmain.ITEMS);
        }
        if (amount == 10) {
            int id = (qty == 2) ? 1 : 4;
            return actions().widgetInteract(MenuAction.CC_OP, id, slot,
                InterfaceID.Bankmain.ITEMS);
        }

        int lastQty = client().varbit(Varbits.BANK_REQUESTEDQUANTITY);
        if (lastQty == amount) {
            int id = (qty == 3) ? 1 : 5;
            return actions().widgetInteract(MenuAction.CC_OP, id, slot,
                InterfaceID.Bankmain.ITEMS);
        }

        // Withdraw-X is op 6 under CC_OP -- observed live, and what the Java
        // reference sends (BankUtils.withdrawItemAmount). The op list is fixed
        // (2=1, 3=5, 4=10, 5=lastX, 6=X, 7=All); op 1 is only a duplicate of
        // whichever quantity the bank buttons have selected, so for qty == 3 it
        // is Withdraw-lastX -- the wrong amount, and no prompt.
        return actions().widgetInteract(MenuAction.CC_OP, 6, slot,
            InterfaceID.Bankmain.ITEMS);
    }

    public static boolean interactItemInBank(int itemId) {
        return interactItemInBank(itemId, 9);
    }

    public static boolean interactItemInBank(int itemId, int identifier) {
        Optional<InventoryItem> slot = findLive(itemId);
        if (slot.isEmpty()) return false;
        return actions().widgetInteract(MenuAction.CC_OP, identifier, slot.get().slot(),
            InterfaceID.Bankmain.ITEMS);
    }

    // --- Opening a bank --------------------------------------------------

    public static boolean isNearBank() {
        return isNearBank(15);
    }

    public static boolean isNearBank(int distance) {
        return Queries.objects(distance)
            .where(o -> BankSets.isBankObject(o.id()))
            .first()
            .isPresent();
    }

    public static boolean open() {
        Optional<Player> local = client().localPlayer();
        Optional<TileObject> nearest = Queries.objects(15)
            .where(o -> BankSets.isBankObject(o.id()))
            .nearest();
        if (nearest.isPresent()) {
            TileObject obj = nearest.get();
            if (obj.interact("Bank")) return true;
            if (obj.interact("Use")) return true;
        }
        if (local.isEmpty()) return false;
        return Queries.npcs()
            .hasAction("Bank")
            .nearestTo(local.get())
            .map(npc -> npc.interact("Bank"))
            .orElse(false);
    }

    // --- PIN helpers -----------------------------------------------------

    /// True while the bank PIN keypad (interface 213) is up.
    ///
    /// Structural, not textual, for the same reason as {@link #isSearchOpen()}:
    /// a text scan for the prompt reads only the primary text slot, matches
    /// case-sensitively, and needs a packed id on the hit, so it misses pads
    /// whose instruction text sits in the secondary slot or carries colour
    /// tags. Visibility already fails when the widget's group is inactive, so
    /// a visible pad child implies the pad is open.
    public static boolean isPinVisible() {
        // FRAME and CANCEL persist for the whole pad session; the digit slots
        // and the shuffled letter keys do not.
        return widgetVisible(InterfaceID.BankpinKeypad.FRAME)
            || widgetVisible(InterfaceID.BankpinKeypad.CANCEL)
            || widgetVisible(InterfaceID.BankpinKeypad.UNIVERSE);
    }

    /// Index (0-3) of the digit the pad is asking for, or -1 when the pad is
    /// down or has not named a digit yet.
    ///
    /// Sweeps every visible widget in the pad group rather than reading
    /// {@code FRAME} alone: the instruction text does not reliably live on
    /// that one child. {@code FRAME} is included in the sweep.
    public static int pinRequestedDigitIndex() {
        for (Widget widget : Queries.widgets(BANKPIN_KEYPAD_GROUP).isVisible().toList()) {
            String txt = widget.text();
            if (containsIgnoreCase(txt, "FIRST")) return 0;
            if (containsIgnoreCase(txt, "SECOND")) return 1;
            if (containsIgnoreCase(txt, "THIRD")) return 2;
            if (containsIgnoreCase(txt, "FOURTH")) return 3;
        }
        return -1;
    }

    public static boolean typePin(String pin) {
        if (pin == null || pin.length() != 4) return false;
        for (int i = 0; i < pin.length(); i++) {
            char c = pin.charAt(i);
            if (c < '0' || c > '9') return false;
        }
        int idx = pinRequestedDigitIndex();
        if (idx < 0 || idx > 3) return false;
        return client().sendKeyboardString(String.valueOf(pin.charAt(idx)));
    }

    // --- Internal helpers ------------------------------------------------

    private static boolean widgetVisible(int packedId) {
        return client().widget(packedId).map(Widget::isVisible).orElse(false);
    }

    private static int bankQuantityType() {
        return client().varbit(Varbits.BANK_QUANTITY_TYPE);
    }

    private static Optional<Integer> inventorySlotOf(int itemId) {
        return client().itemContainer(InventoryId.INVENTORY)
            .flatMap(inv -> inv.items().stream()
                .filter(item -> item.id() == itemId)
                .map(InventoryItem::slot)
                .findFirst());
    }

    private static String itemName(InventoryItem item) {
        String name = item.name();
        if (name != null && !name.isEmpty()) return name;
        return client().itemComposition(item.id())
            .map(comp -> comp.name())
            .orElse("");
    }

    private static boolean containsIgnoreCase(String haystack, String needle) {
        if (needle == null || needle.isEmpty()) return true;
        if (haystack == null) return false;
        return haystack.toLowerCase().contains(needle.toLowerCase());
    }
}
