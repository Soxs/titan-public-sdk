package net.titan.api;

import net.titan.api.internal.InteractionBackend;
import net.titan.api.internal.TitanRuntime;
import net.titan.api.utils.Magic;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.OptionalInt;

public final class Widget {
    private boolean liveHandle = true;
    private int screenX;
    private int screenY;
    private int width;
    private int height;
    private int relativeX;
    private int relativeY;
    private int scrollX;
    private int scrollY;
    private int type;
    private int contentType;
    private int spriteId = -1;
    private int modelType = -1;
    private int modelId = -1;
    private int opacity;
    private int itemId = -1;
    private int itemQuantity;
    private int parentId = -1;
    private boolean hidden;
    private boolean selfHidden;
    private boolean visible;
    private String text;
    private int packedId;
    private int dynamicParentPackedId;
    private int dynamicChildSlot = -1;
    private int rootPackedId;
    private List<Integer> dynamicPath;

    private Widget live() { return TitanRuntime.currentLive(this); }

    public int screenX() { return live().screenX; }
    public int screenY() { return live().screenY; }
    public int width() { return live().width; }
    public int height() { return live().height; }
    public int relativeX() { return live().relativeX; }
    public int relativeY() { return live().relativeY; }
    public int scrollX() { return live().scrollX; }
    public int scrollY() { return live().scrollY; }
    /** Current scroll content height of a root or direct child on the game thread. */
    public OptionalInt scrollHeight() { return TitanRuntime.widgetScrollHeight(address()); }
    /** Primary text on the game thread, or null when unavailable. Empty text and all characters are preserved. */
    public String primaryText() { return TitanRuntime.widgetPrimaryText(address()); }
    public int type() { return live().type; }
    public int contentType() { return live().contentType; }
    public int spriteId() { return live().spriteId; }
    /**
     * Model source kind stored by the client, matching RuneLite's
     * {@code WidgetModelType}: 0 none, 1 model, 2 NPC chathead, 3 local player
     * chathead, 4 item, 5 player, 6 NPC chathead by index. -1 when unavailable.
     */
    public int modelType() { return live().modelType; }
    /** Id selected by {@link #modelType()}, or -1 when the widget has no model. */
    public int modelId() { return live().modelId; }
    public int opacity() { return live().opacity; }
    public int itemId() { return live().itemId; }
    public int itemQuantity() { return live().itemQuantity; }
    public int parentId() { return live().parentId; }
    public boolean isHidden() { return live().hidden; }
    public boolean isSelfHidden() { return live().selfHidden; }
    public boolean isVisible() { return live().visible; }
    public String text() {
        String value = live().text;
        return value == null ? "" : value;
    }
    /**
     * Op base, read live at {@link #address()} (RuneLite {@code Widget.getName()}),
     * e.g. {@code "<col=ff9040>Shark</col>"} on an inventory slot. {@code ""} when
     * the widget has no op base; null when the host cannot read it. Non-breaking
     * spaces read as spaces. SDK 159.
     */
    public String name() { return TitanRuntime.widgetName(address()); }
    /**
     * Op strings, read live (RuneLite {@code Widget.getActions()}): one entry per
     * native slot, null where unset. Null when the widget has no op array or when
     * the host cannot read it; {@link #opsAvailable()} tells the two apart. SDK 159.
     */
    public String[] actions() {
        String[] slots = TitanRuntime.widgetActions(address());
        return slots == null || slots.length == 0 ? null : slots;
    }
    /** Whether the host can read this widget's name and actions now. SDK 159. */
    public boolean opsAvailable() { return name() != null; }
    /**
     * Reads the inventory-transmit script and its arguments in native order.
     * Values are Integer, String or Long. An unset listener returns null.
     * @throws UnsupportedOperationException when this address, thread or host cannot supply the listener
     */
    public Object[] inventoryTransmitListener() {
        return TitanRuntime.widgetInventoryTransmitListener(address());
    }
    /** Reads an owned copy of the keypress script and arguments with the same contract as {@link #inventoryTransmitListener()}. */
    public Object[] keyListener() {
        return TitanRuntime.widgetKeyListener(address());
    }
    public int packedId() { return live().packedId; }
    public int dynamicParentPackedId() { return live().dynamicParentPackedId; }
    public int dynamicChildSlot() { return live().dynamicChildSlot; }
    public int rootPackedId() { return live().rootPackedId; }
    public List<Integer> dynamicPath() {
        List<Integer> value = live().dynamicPath;
        return value == null
            ? Collections.emptyList()
            : Collections.unmodifiableList(value);
    }

    public WidgetAddress address() {
        // The wire carries a retained address, including zero as a valid root.
        // These identity fields do not need a live content refresh.
        if (dynamicPath != null && !dynamicPath.isEmpty())
            return new WidgetAddress(rootPackedId, dynamicPath);
        if (dynamicChildSlot >= 0)
            return new WidgetAddress(rootPackedId != 0 ? rootPackedId : dynamicParentPackedId,
                Collections.singletonList(dynamicChildSlot));
        return new WidgetAddress(rootPackedId != 0 ? rootPackedId : packedId, Collections.emptyList());
    }

    public boolean isDynamic() {
        return dynamicChildSlot() >= 0 || !dynamicPath().isEmpty();
    }

    /**
     * Queues a native menu interaction. The host tries the action names in order
     * on this widget, then on each visible direct child in slot order. Each name
     * matches case-insensitively, preferring an exact label before a substring
     * match. For {@code "Op/Subop"}, both parts must match the same submenu path,
     * with an exact match on both parts preferred. When a spell or item is
     * already selected, an eligible widget receives that selection even if
     * its targeting verb differs from the supplied names.
     *
     * @param actions action names in preference order, ignoring null and blank names
     * @return true when the host queued the request. Matching and dispatch happen
     *         later on the game thread, so a queued request can find no eligible entry.
     */
    public boolean interact(String... actions) {
        if (actions == null || actions.length == 0) return false;
        String[] labels = Arrays.stream(actions)
            .filter(Widget::hasActionText)
            .toArray(String[]::new);
        return labels.length != 0
            && TitanRuntime.getInteractionBackend().widgetInteractByActions(address(), labels);
    }

    private static boolean hasActionText(String label) {
        if (label == null) return false;
        // The native menu normalizes NBSP and trims ASCII whitespace.
        for (int i = 0; i < label.length(); i++) {
            char c = label.charAt(i);
            if (c != ' ' && c != '\u00a0' && (c < '\t' || c > '\r')) return true;
        }
        return false;
    }

    public boolean interact(int opcode, int identifier, int param0, int param1) {
        return TitanRuntime.getInteractionBackend().widgetInteract(
            opcode, identifier, param0, param1);
    }

    public boolean interact(int opcode, int identifier, int childSlot) {
        InteractionBackend actions = TitanRuntime.getInteractionBackend();
        if (isDynamic()) {
            return actions.widgetInteractAtPath(address(), opcode, identifier, childSlot);
        }
        return actions.widgetInteract(opcode, identifier, childSlot, packedId());
    }

    public boolean interact(int opcode, int identifier) {
        int slot = dynamicChildSlot() >= 0 ? dynamicChildSlot() : -1;
        InteractionBackend actions = TitanRuntime.getInteractionBackend();
        if (isDynamic()) {
            return actions.widgetInteractAtPath(address(), opcode, identifier, -1);
        }
        return actions.widgetInteract(opcode, identifier, slot, packedId());
    }

    public boolean setText(String value) {
        InteractionBackend actions = TitanRuntime.getInteractionBackend();
        boolean ok;
        if (isDynamic()) {
            ok = actions.setWidgetTextAtPath(address(), value);
        } else {
            ok = actions.setWidgetText(packedId(), value);
        }
        if (ok) text = value == null ? "" : value;
        return ok;
    }

    /** Changes of this widget's own fields, on the game thread. SDK 188. */
    public WidgetEdit edit() { return new WidgetEdit(address()); }

    public boolean castOn(Magic.SpellInfo spell) { return Magic.castOn(spell, this); }
    public boolean castOn(Magic.Standard spell) { return Magic.castOn(spell, this); }
    public boolean castOn(Magic.Ancient spell) { return Magic.castOn(spell, this); }
    public boolean castOn(Magic.Lunar spell) { return Magic.castOn(spell, this); }
    public boolean castOn(Magic.Necromancy spell) { return Magic.castOn(spell, this); }

    public boolean exists() { return TitanRuntime.liveExists(this); }

    public Widget snapshot() { return TitanRuntime.snapshotLive(this); }

    @Override
    public boolean equals(Object other) {
        return TitanRuntime.liveEquals(this, other);
    }

    @Override
    public int hashCode() {
        return TitanRuntime.liveHashCode(this);
    }
}
