package net.titan.api.internal;

import net.titan.api.ScreenPoint;
import net.titan.api.overlay.OverlayPanelStyle;

import java.util.Optional;
import java.util.OptionalLong;

public interface OverlayBackend {
    void tileQuad(int tileX, int tileY, int plane, int fillColor, int outlineColor);
    void tileRegion(int minTileX, int minTileY, int maxTileX, int maxTileY,
                    int plane, int fillColor, int outlineColor);
    void tileQuadInWorldView(int worldViewId, int tileX, int tileY, int plane,
                             int fillColor, int outlineColor);
    void tileRegionInWorldView(int worldViewId, int minTileX, int minTileY,
                               int maxTileX, int maxTileY, int plane,
                               int fillColor, int outlineColor);
    void entityBox(int preciseX, int preciseY, int plane,
                   int tileSize, int height, int color);
    void entityClickbox(long entityPtr, long typecode, int outline, int fill);
    void tileObjectClickbox(long locPtr, long typecode, int outline, int fill);
    void entityHull(long entityPtr, long typecode, int outline, int fill);
    void tileObjectHull(long locPtr, long typecode, int outline, int fill);
    void entityOutline(long entityPtr, long typecode, int outline, int fill, int mode);
    void tileObjectOutline(long locPtr, long typecode, int outline, int fill, int mode);
    /** The convex outline as x, y pairs. Empty on an older host. */
    default int[] tileObjectOutlinePoints(long locPtr, long typecode) { return new int[0]; }
    /** The same of a player or NPC. Empty on an older host. */
    default int[] entityOutlinePoints(long entityPtr) { return new int[0]; }
    /** -1 for one which has not been drawn lately, and on an older host. */
    default int entityModelHeight(long entityPtr) { return -1; }
    void textAtWorld(int worldX, int worldY, int worldZ,
                     String text, int color, boolean centered);
    void textAtWorldInWorldView(int worldViewId, int preciseX, int worldY,
                                int preciseY, int plane, String text,
                                int color, boolean centered);
    void screenText(int x, int y, String text, int color);
    void screenRect(int x, int y, int width, int height, int color);
    void screenLine(int x1, int y1, int x2, int y2, int color, float thickness);
    Optional<ScreenPoint> worldToScreen(int worldX, int worldY, int worldZ);
    Optional<ScreenPoint> worldToScreenInWorldView(int worldViewId, int preciseX,
                                                   int worldY, int preciseY,
                                                   int plane);
    Optional<ScreenPoint> tileToScreen(int tileX, int tileY, int plane, int heightOffset);
    int tileHeight(int preciseX, int preciseY, int plane);
    int tileHeightInWorldView(int worldViewId, int preciseX, int preciseY, int plane);

    /**
     * Pack a target tag with the host's layout for the running revision
     * (SDK 172). Empty when the host or runtime cannot.
     */
    default OptionalLong packTargetTag(int tileX, int tileY, int plane, int kind,
                                       int index, int worldViewId) {
        return OptionalLong.empty();
    }

    int overlayPanelRegister(String pluginId, String panelName,
                             int defaultAnchor, int defaultPriority);
    void overlayPanelUnregister(int handle);
    void overlayPanelBegin(int handle, int preferredWidth);
    void overlayPanelEnd(int handle);
    default boolean infoBoxSetIcon(String owner, int panel, int key, int width, int height, int[] argb) {
        throw new UnsupportedOperationException("This Titan host does not provide HUD infoboxes");
    }
    default boolean infoBoxPresent(String owner, int panel, boolean vertical, int size, java.util.List<net.titan.api.overlay.InfoBoxTile> tiles) {
        throw new UnsupportedOperationException("This Titan host does not provide HUD infoboxes");
    }
    void overlayPanelSetStyle(int handle, OverlayPanelStyle style);
    void overlayPanelTitle(int handle, String text, int color);
    void overlayPanelLine(int handle, String left, String right,
                          int leftColor, int rightColor);
    void overlayPanelProgressBar(int handle, int value, int minValue,
                                 int maxValue, int fillColor, int backgroundColor);
}
