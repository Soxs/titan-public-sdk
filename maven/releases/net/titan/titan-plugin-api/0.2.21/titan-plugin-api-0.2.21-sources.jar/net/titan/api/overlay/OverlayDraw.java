package net.titan.api.overlay;

import net.titan.api.NPC;
import net.titan.api.Client;
import net.titan.api.LocalPoint;
import net.titan.api.Locatable;
import net.titan.api.Player;
import net.titan.api.ScreenPoint;
import net.titan.api.TileObject;
import net.titan.api.WorldView;
import net.titan.api.WorldPoint;
import net.titan.api.Titan;
import net.titan.api.internal.TitanRuntime;

import java.util.Optional;
import java.util.OptionalLong;

public final class OverlayDraw {
    /** Draw owned ARGB32 pixels at the canvas origin during this overlay pass. */
    public boolean sprite(net.titan.api.SpriteImage image, int x, int y) {
        return net.titan.api.Titan.itemSprites().draw(image, x, y);
    }

    public boolean sprite(net.titan.api.SpriteImage image, int x, int y, float scale) {
        return net.titan.api.Titan.itemSprites().draw(image, x, y, scale);
    }

    private static final OverlayDraw INSTANCE = new OverlayDraw();

    private OverlayDraw() {}

    public static OverlayDraw current() {
        return INSTANCE;
    }

    public void tileQuad(int tileX, int tileY, int plane,
                         int fillColor, int outlineColor) {
        TitanRuntime.getOverlayBackend().tileQuad(
            tileX, tileY, plane, fillColor, outlineColor);
    }

    public void tileRegion(int minTileX, int minTileY, int maxTileX, int maxTileY,
                           int plane, int fillColor, int outlineColor) {
        TitanRuntime.getOverlayBackend().tileRegion(
            minTileX, minTileY, maxTileX, maxTileY, plane, fillColor, outlineColor);
    }

    public void tileQuadInWorldView(int worldViewId, int tileX, int tileY,
                                    int plane, int fillColor, int outlineColor) {
        TitanRuntime.getOverlayBackend().tileQuadInWorldView(
            worldViewId, tileX, tileY, plane, fillColor, outlineColor);
    }

    public void tileRegionInWorldView(int worldViewId, int minTileX, int minTileY,
                                      int maxTileX, int maxTileY, int plane,
                                      int fillColor, int outlineColor) {
        TitanRuntime.getOverlayBackend().tileRegionInWorldView(
            worldViewId, minTileX, minTileY, maxTileX, maxTileY, plane,
            fillColor, outlineColor);
    }

    public void worldTileRegionInWorldView(int worldViewId,
                                           int minWorldX, int minWorldY,
                                           int maxWorldX, int maxWorldY,
                                           int plane, int fillColor,
                                           int outlineColor) {
        Client client = Titan.client();
        int baseX = worldViewId == WorldView.TOP_LEVEL ? client.topLevelBaseX() : client.baseX();
        int baseY = worldViewId == WorldView.TOP_LEVEL ? client.topLevelBaseY() : client.baseY();
        tileRegionInWorldView(worldViewId,
            minWorldX - baseX, minWorldY - baseY,
            maxWorldX - baseX, maxWorldY - baseY,
            plane, fillColor, outlineColor);
    }

    public void entityBox(int preciseX, int preciseY, int plane,
                          int tileSize, int height, int color) {
        TitanRuntime.getOverlayBackend().entityBox(
            preciseX, preciseY, plane, tileSize, height, color);
    }

    private void entityBoxInWorldView(int worldViewId, int preciseX,
                                      int preciseY, int plane, int tileSize,
                                      int height, int color) {
        int half = tileSize * 64;
        int x0 = preciseX - half;
        int x1 = preciseX + half;
        int z0 = preciseY - half;
        int z1 = preciseY + half;
        int groundY = tileHeightInWorldView(worldViewId, preciseX, preciseY, plane);

        Optional<ScreenPoint>[] bottom = new Optional[] {
            worldToScreenInWorldView(worldViewId, x0, groundY, z0, plane),
            worldToScreenInWorldView(worldViewId, x1, groundY, z0, plane),
            worldToScreenInWorldView(worldViewId, x1, groundY, z1, plane),
            worldToScreenInWorldView(worldViewId, x0, groundY, z1, plane)
        };
        Optional<ScreenPoint>[] top = new Optional[] {
            worldToScreenInWorldView(worldViewId, x0, groundY - height, z0, plane),
            worldToScreenInWorldView(worldViewId, x1, groundY - height, z0, plane),
            worldToScreenInWorldView(worldViewId, x1, groundY - height, z1, plane),
            worldToScreenInWorldView(worldViewId, x0, groundY - height, z1, plane)
        };

        for (int i = 0; i < 4; ++i) {
            lineIfPresent(bottom[i], bottom[(i + 1) % 4], color);
            lineIfPresent(top[i], top[(i + 1) % 4], color);
            lineIfPresent(bottom[i], top[i], color);
        }
    }

    private void lineIfPresent(Optional<ScreenPoint> a, Optional<ScreenPoint> b, int color) {
        if (!a.isPresent() || !b.isPresent()) return;
        screenLine(a.get().x(), a.get().y(), b.get().x(), b.get().y(), color, 1.5f);
    }

    public void entityBox(NPC npc, int color) {
        entityBox(npc, color, 240);
    }

    public void entityBox(NPC npc, int color, int height) {
        if (npc == null) return;
        entityBoxInWorldView(npc.worldViewId(), npc.preciseX(), npc.preciseY(),
            npc.plane(), 1, height, color);
    }

    public void entityBox(Player player, int color) {
        entityBox(player, color, 240);
    }

    public void entityBox(Player player, int color, int height) {
        if (player == null) return;
        entityBoxInWorldView(player.worldViewId(), player.preciseX(), player.preciseY(),
            player.plane(), 1, height, color);
    }

    public void entityClickbox(NPC npc, int outline) {
        entityClickbox(npc, outline, 0);
    }

    public void entityClickbox(NPC npc, int outline, int fill) {
        if (npc == null) return;
        long typecode = buildActorTypecode(
            1, npc.hashIndex(), npc.preciseX() >> 7, npc.preciseY() >> 7, npc.plane());
        entityClickbox(npc.entityPtr(), typecode, outline, fill);
    }

    public void entityClickbox(Player player, int outline) {
        entityClickbox(player, outline, 0);
    }

    public void entityClickbox(Player player, int outline, int fill) {
        if (player == null) return;
        long typecode = buildActorTypecode(
            0, player.hashIndex(), player.preciseX() >> 7, player.preciseY() >> 7, player.plane());
        entityClickbox(player.entityPtr(), typecode, outline, fill);
    }

    public void entityClickbox(long entityPtr, long typecode, int outline, int fill) {
        TitanRuntime.getOverlayBackend().entityClickbox(entityPtr, typecode, outline, fill);
    }

    public void tileObjectClickbox(TileObject object, int outline) {
        tileObjectClickbox(object, outline, 0);
    }

    public void tileObjectClickbox(TileObject object, int outline, int fill) {
        if (object == null) return;
        long typecode = object.packedId();
        tileObjectClickbox(object.entityPtr(), typecode, outline, fill);
    }

    public void tileObjectClickbox(long locPtr, long typecode, int outline, int fill) {
        TitanRuntime.getOverlayBackend().tileObjectClickbox(locPtr, typecode, outline, fill);
    }

    public void entityHull(NPC npc, int outline) {
        entityHull(npc, outline, 0);
    }

    public void entityHull(NPC npc, int outline, int fill) {
        if (npc == null) return;
        long typecode = buildActorTypecode(
            1, npc.hashIndex(), npc.preciseX() >> 7, npc.preciseY() >> 7, npc.plane());
        entityHull(npc.entityPtr(), typecode, outline, fill);
    }

    public void entityHull(Player player, int outline) {
        entityHull(player, outline, 0);
    }

    public void entityHull(Player player, int outline, int fill) {
        if (player == null) return;
        long typecode = buildActorTypecode(
            0, player.hashIndex(), player.preciseX() >> 7, player.preciseY() >> 7, player.plane());
        entityHull(player.entityPtr(), typecode, outline, fill);
    }

    public void entityHull(long entityPtr, long typecode, int outline, int fill) {
        TitanRuntime.getOverlayBackend().entityHull(entityPtr, typecode, outline, fill);
    }

    public void tileObjectHull(TileObject object, int outline) {
        tileObjectHull(object, outline, 0);
    }

    public void tileObjectHull(TileObject object, int outline, int fill) {
        if (object == null) return;
        long typecode = object.packedId();
        tileObjectHull(object.entityPtr(), typecode, outline, fill);
    }

    public void tileObjectHull(long locPtr, long typecode, int outline, int fill) {
        TitanRuntime.getOverlayBackend().tileObjectHull(locPtr, typecode, outline, fill);
    }

    /**
     * Draw the TRUE model silhouette: the 2D convex hull of the entity's
     * actual projected model vertices, rotated and placed exactly where the
     * engine renders it. Tighter than {@link #entityHull} (which hulls the 8
     * AABB corners) -- irregular / tall-thin models get a real outline. No-op
     * on hosts older than SDK 122 or when the model handle isn't bound this
     * frame (host model-AABB hook inactive / revision without Model geometry).
     */
    public void entityOutline(NPC npc, int outline) {
        entityOutline(npc, outline, 0, OutlineMode.CONVEX);
    }

    public void entityOutline(NPC npc, int outline, int fill) {
        entityOutline(npc, outline, fill, OutlineMode.CONVEX);
    }

    public void entityOutline(NPC npc, int outline, int fill, OutlineMode mode) {
        if (npc == null) return;
        long typecode = buildActorTypecode(
            1, npc.hashIndex(), npc.preciseX() >> 7, npc.preciseY() >> 7, npc.plane());
        entityOutline(npc.entityPtr(), typecode, outline, fill, mode);
    }

    public void entityOutline(Player player, int outline) {
        entityOutline(player, outline, 0, OutlineMode.CONVEX);
    }

    public void entityOutline(Player player, int outline, int fill) {
        entityOutline(player, outline, fill, OutlineMode.CONVEX);
    }

    public void entityOutline(Player player, int outline, int fill, OutlineMode mode) {
        if (player == null) return;
        long typecode = buildActorTypecode(
            0, player.hashIndex(), player.preciseX() >> 7, player.preciseY() >> 7, player.plane());
        entityOutline(player.entityPtr(), typecode, outline, fill, mode);
    }

    public void entityOutline(long entityPtr, long typecode, int outline, int fill) {
        entityOutline(entityPtr, typecode, outline, fill, OutlineMode.CONVEX);
    }

    public void entityOutline(long entityPtr, long typecode, int outline, int fill,
                              OutlineMode mode) {
        TitanRuntime.getOverlayBackend().entityOutline(
            entityPtr, typecode, outline, fill,
            (mode == null ? OutlineMode.CONVEX : mode).value());
    }

    public void tileObjectOutline(TileObject object, int outline) {
        tileObjectOutline(object, outline, 0, OutlineMode.CONVEX);
    }

    public void tileObjectOutline(TileObject object, int outline, int fill) {
        tileObjectOutline(object, outline, fill, OutlineMode.CONVEX);
    }

    public void tileObjectOutline(TileObject object, int outline, int fill, OutlineMode mode) {
        if (object == null) return;
        long typecode = object.packedId();
        tileObjectOutline(object.entityPtr(), typecode, outline, fill, mode);
    }

    public void tileObjectOutline(long locPtr, long typecode, int outline, int fill) {
        tileObjectOutline(locPtr, typecode, outline, fill, OutlineMode.CONVEX);
    }

    public void tileObjectOutline(long locPtr, long typecode, int outline, int fill,
                                  OutlineMode mode) {
        TitanRuntime.getOverlayBackend().tileObjectOutline(
            locPtr, typecode, outline, fill,
            (mode == null ? OutlineMode.CONVEX : mode).value());
    }

    /**
     * The convex outline of an object on the canvas, in order, for a plugin which tests or draws it by itself
     * (SDK 190). Asking makes the host capture the model: the first answers are its bounding box's, or empty.
     * Empty too for an object which is gone or out of view.
     */
    public java.util.List<ScreenPoint> tileObjectOutlinePoints(TileObject object) {
        if (object == null) return java.util.Collections.emptyList();
        return screenPoints(TitanRuntime.getOverlayBackend().tileObjectOutlinePoints(object.entityPtr(), object.packedId()));
    }

    /**
     * The convex outline of an NPC on the canvas, in order, as {@link #tileObjectOutlinePoints} gives an object's
     * (SDK 191). Empty for one which is out of view, and for the first frame in which it is asked for.
     */
    public java.util.List<ScreenPoint> entityOutlinePoints(NPC npc) {
        return npc == null ? java.util.Collections.emptyList()
            : screenPoints(TitanRuntime.getOverlayBackend().entityOutlinePoints(npc.entityPtr()));
    }
    /** The same of a player. */
    public java.util.List<ScreenPoint> entityOutlinePoints(Player player) {
        return player == null ? java.util.Collections.emptyList()
            : screenPoints(TitanRuntime.getOverlayBackend().entityOutlinePoints(player.entityPtr()));
    }

    /**
     * How far an NPC's model rises above the ground it stands on, in the units of its precise position, for a text
     * above its head (SDK 191). -1 when the game has not drawn it lately.
     */
    public int entityModelHeight(NPC npc) { return npc == null ? -1 : TitanRuntime.getOverlayBackend().entityModelHeight(npc.entityPtr()); }
    /** The same of a player. */
    public int entityModelHeight(Player player) { return player == null ? -1 : TitanRuntime.getOverlayBackend().entityModelHeight(player.entityPtr()); }

    private static java.util.List<ScreenPoint> screenPoints(int[] points) {
        java.util.List<ScreenPoint> out = new java.util.ArrayList<>(points.length / 2);
        for (int i = 0; i + 1 < points.length; i += 2) out.add(new ScreenPoint(points[i], points[i + 1]));
        return java.util.Collections.unmodifiableList(out);
    }

    public void textAtWorld(int worldX, int worldY, int worldZ,
                            String text, int color) {
        textAtWorld(worldX, worldY, worldZ, text, color, true);
    }

    public void textAtWorld(int worldX, int worldY, int worldZ,
                            String text, int color, boolean centered) {
        TitanRuntime.getOverlayBackend().textAtWorld(
            worldX, worldY, worldZ, text, color, centered);
    }

    public void textAtWorld(WorldPoint point, String text, int color) {
        textAtWorld(point, text, color, true);
    }

    public void textAtWorld(WorldPoint point, String text, int color, boolean centered) {
        if (point == null) return;
        textAtWorld(point.x(), point.y(), point.z(), text, color, centered);
    }

    public void textAtWorldInWorldView(int worldViewId, int preciseX, int worldY,
                                       int preciseY, int plane, String text,
                                       int color) {
        textAtWorldInWorldView(worldViewId, preciseX, worldY, preciseY, plane,
                               text, color, true);
    }

    public void textAtWorldInWorldView(int worldViewId, int preciseX, int worldY,
                                       int preciseY, int plane, String text,
                                       int color, boolean centered) {
        TitanRuntime.getOverlayBackend().textAtWorldInWorldView(
            worldViewId, preciseX, worldY, preciseY, plane, text, color, centered);
    }

    public void textAtWorld(LocalPoint point, int worldY, int plane,
                            String text, int color) {
        textAtWorld(point, worldY, plane, text, color, true);
    }

    public void textAtWorld(LocalPoint point, int worldY, int plane,
                            String text, int color, boolean centered) {
        if (point == null) return;
        textAtWorldInWorldView(point.worldViewId(), point.x(), worldY,
                               point.y(), plane, text, color, centered);
    }

    public void textAtWorld(Locatable<?> locatable, int worldY,
                            String text, int color) {
        textAtWorld(locatable, worldY, text, color, true);
    }

    public void textAtWorld(Locatable<?> locatable, int worldY,
                            String text, int color, boolean centered) {
        if (locatable == null) return;
        textAtWorld(locatable.localPoint(), worldY, locatable.plane(),
                    text, color, centered);
    }

    public void textAtWorldTileInWorldView(int worldViewId,
                                           int worldTileX, int worldY,
                                           int worldTileY, int plane,
                                           String text, int color) {
        textAtWorldTileInWorldView(worldViewId, worldTileX, worldY, worldTileY,
                                   plane, text, color, true);
    }

    public void textAtWorldTileInWorldView(int worldViewId,
                                           int worldTileX, int worldY,
                                           int worldTileY, int plane,
                                           String text, int color,
                                           boolean centered) {
        Client client = Titan.client();
        int baseX = worldViewId == WorldView.TOP_LEVEL ? client.topLevelBaseX() : client.baseX();
        int baseY = worldViewId == WorldView.TOP_LEVEL ? client.topLevelBaseY() : client.baseY();
        textAtWorldInWorldView(worldViewId,
            (worldTileX - baseX) * 128, worldY, (worldTileY - baseY) * 128,
            plane, text, color, centered);
    }

    public void screenText(int x, int y, String text, int color) {
        TitanRuntime.getOverlayBackend().screenText(x, y, text, color);
    }

    public void screenRect(int x, int y, int width, int height, int color) {
        TitanRuntime.getOverlayBackend().screenRect(x, y, width, height, color);
    }

    public void screenLine(int x1, int y1, int x2, int y2, int color) {
        screenLine(x1, y1, x2, y2, color, 1.0f);
    }

    public void screenLine(int x1, int y1, int x2, int y2, int color, float thickness) {
        TitanRuntime.getOverlayBackend().screenLine(x1, y1, x2, y2, color, thickness);
    }

    public Optional<ScreenPoint> worldToScreen(int worldX, int worldY, int worldZ) {
        return TitanRuntime.getOverlayBackend().worldToScreen(worldX, worldY, worldZ);
    }

    public Optional<ScreenPoint> worldToScreen(WorldPoint point) {
        return point == null ? Optional.empty() : worldToScreen(point.x(), point.y(), point.z());
    }

    public Optional<ScreenPoint> worldToScreenInWorldView(int worldViewId,
                                                          int preciseX,
                                                          int worldY,
                                                          int preciseY,
                                                          int plane) {
        return TitanRuntime.getOverlayBackend().worldToScreenInWorldView(
            worldViewId, preciseX, worldY, preciseY, plane);
    }

    public Optional<ScreenPoint> worldToScreen(LocalPoint point, int worldY, int plane) {
        return point == null
            ? Optional.empty()
            : worldToScreenInWorldView(point.worldViewId(), point.x(), worldY, point.y(), plane);
    }

    public Optional<ScreenPoint> worldToScreen(Locatable<?> locatable, int worldY) {
        return locatable == null
            ? Optional.empty()
            : worldToScreen(locatable.localPoint(), worldY, locatable.plane());
    }

    public Optional<ScreenPoint> tileToScreen(int tileX, int tileY, int plane) {
        return tileToScreen(tileX, tileY, plane, 0);
    }

    public Optional<ScreenPoint> tileToScreen(int tileX, int tileY, int plane, int heightOffset) {
        return TitanRuntime.getOverlayBackend().tileToScreen(tileX, tileY, plane, heightOffset);
    }

    public int tileHeight(int preciseX, int preciseY, int plane) {
        return TitanRuntime.getOverlayBackend().tileHeight(preciseX, preciseY, plane);
    }

    public int tileHeightInWorldView(int worldViewId, int preciseX, int preciseY, int plane) {
        return TitanRuntime.getOverlayBackend().tileHeightInWorldView(
            worldViewId, preciseX, preciseY, plane);
    }

    public int tileHeight(LocalPoint point, int plane) {
        return point == null ? 0 : tileHeightInWorldView(point.worldViewId(), point.x(), point.y(), plane);
    }

    public int worldTileHeightInWorldView(int worldViewId,
                                          int worldTileX, int worldTileY,
                                          int plane) {
        Client client = Titan.client();
        int baseX = worldViewId == WorldView.TOP_LEVEL ? client.topLevelBaseX() : client.baseX();
        int baseY = worldViewId == WorldView.TOP_LEVEL ? client.topLevelBaseY() : client.baseY();
        return tileHeightInWorldView(worldViewId,
            (worldTileX - baseX) * 128, (worldTileY - baseY) * 128, plane);
    }

    /**
     * Build the engine's target tag (the key the scene, menu builders and
     * mouse picker share) for an actor: {@code entityType} 0 player, 1 NPC.
     * The host packs it with the layout of the revision it runs -- 242.1
     * widened the index and moved the WorldView id -- and hosts older than
     * SDK 172 get the pre-242.1 layout. 0 when {@code hashIndex} is negative.
     */
    public static long buildActorTypecode(int entityType, int hashIndex,
                                          int tileX, int tileY, int plane) {
        if (hashIndex < 0) return 0L;
        return packTargetTag(tileX, tileY, plane, entityType, hashIndex, WorldView.TOP_LEVEL);
    }

    public static long buildLocTypecode(int locId, int layer,
                                        int tileX, int tileY, int plane) {
        return buildLocTypecode(locId, layer, tileX, tileY, plane, WorldView.TOP_LEVEL);
    }

    /**
     * Build a loc's target tag, packed by the host like
     * {@link #buildActorTypecode}. Prefer {@link TileObject#packedId()}, the
     * native tag itself, when you have the object.
     */
    public static long buildLocTypecode(int locId, int layer,
                                        int tileX, int tileY, int plane,
                                        int worldViewId) {
        // Native loc picking uses the raw scene tag; layer is kept in
        // the signature for source compatibility.
        if (locId < 0) return 0L;
        return packTargetTag(tileX, tileY, plane, TARGET_TAG_LOC_KIND, locId, worldViewId);
    }

    /** Kind-field value of a loc in a target tag (0 player, 1 NPC). */
    private static final int TARGET_TAG_LOC_KIND = 2;

    /**
     * One field of the pre-242.1 target-tag layout. Only hosts older than
     * SDK 172, which cannot pack tags, still use it.
     */
    private static final class LegacyTargetTagField {
        private final int shift;
        private final long mask;

        LegacyTargetTagField(int shift, long mask) {
            this.shift = shift;
            this.mask = mask;
        }

        long put(int value) {
            return (value & mask) << shift;
        }
    }

    private static final LegacyTargetTagField LEGACY_TAG_X = new LegacyTargetTagField(0, 0x7FL);
    private static final LegacyTargetTagField LEGACY_TAG_Y = new LegacyTargetTagField(7, 0x7FL);
    private static final LegacyTargetTagField LEGACY_TAG_PLANE = new LegacyTargetTagField(14, 0x3L);
    private static final LegacyTargetTagField LEGACY_TAG_KIND = new LegacyTargetTagField(16, 0x7L);
    private static final LegacyTargetTagField LEGACY_TAG_INDEX = new LegacyTargetTagField(20, 0xFFFFL);
    private static final LegacyTargetTagField LEGACY_TAG_WORLD_VIEW = new LegacyTargetTagField(36, 0xFFFFL);

    private static long packTargetTag(int tileX, int tileY, int plane, int kind,
                                      int index, int worldViewId) {
        OptionalLong packed = TitanRuntime.packTargetTag(
            tileX, tileY, plane, kind, index, worldViewId);
        if (packed.isPresent()) return packed.getAsLong();
        return LEGACY_TAG_X.put(tileX) | LEGACY_TAG_Y.put(tileY)
            | LEGACY_TAG_PLANE.put(plane) | LEGACY_TAG_KIND.put(kind)
            | LEGACY_TAG_INDEX.put(index)
            | LEGACY_TAG_WORLD_VIEW.put(worldViewId < 0 ? 0 : worldViewId);
    }
}
